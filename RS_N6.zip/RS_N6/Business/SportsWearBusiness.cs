﻿using Dataa;
using Dataa.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Business
{
    public class SportsWearBusiness
    {
        private SportsWearDBContext sportsWearDBContext;
        public List<Product> GetAll()
        {
            using (sportsWearDBContext = new SportsWearDBContext())
            {
                return sportsWearDBContext.Products.ToList();
            }
        }
        public Product Get(int id)
        {
            using (sportsWearDBContext = new SportsWearDBContext())
            {
                return sportsWearDBContext.Products.Find(id);
            }
        }

        public void Add(Product product)
        {
            using (sportsWearDBContext = new SportsWearDBContext())
            {
                sportsWearDBContext.Products.Add(product);
                sportsWearDBContext.SaveChanges();
            }

        }

        public void Update(Product product)
        {
            using (sportsWearDBContext = new SportsWearDBContext())
            {

                var item = sportsWearDBContext.Products.Find(product.Id);
                if (item != null)
                {
                    sportsWearDBContext.Entry(item).CurrentValues.SetValues(product);
                    sportsWearDBContext.SaveChanges();

                }

            }
        }
        public void Delete(int id)
        {
            using (sportsWearDBContext = new SportsWearDBContext())
            {
                var product = sportsWearDBContext.Products.Find(id);
                if (product != null)
                {
                    sportsWearDBContext.Products.Remove(product);
                    sportsWearDBContext.SaveChanges();

                }

            }
        }





    }
}

