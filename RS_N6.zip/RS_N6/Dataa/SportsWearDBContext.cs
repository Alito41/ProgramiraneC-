﻿using Dataa.Model;
using Microsoft.EntityFrameworkCore;
using System;

namespace Dataa
{
    public class SportsWearDBContext : DbContext
    {
              
            public SportsWearDBContext()
            {
                Database.EnsureCreated();
            }
            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                optionsBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SportsWearDB;");
            }
        public DbSet<Brand> Brands { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Gender> Genders { get; set; }
    }
    }


