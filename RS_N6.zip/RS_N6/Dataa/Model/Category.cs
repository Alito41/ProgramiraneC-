﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dataa.Model
{
   public class Category
    {
        public int Id { get; set; }
        public List<Product> Product { get; set; }
        [StringLength(30)]
        [Required]
        public string CategoryName { get; set; }
        [StringLength(30)]
        public string TypeSport{ get; set; }
        [StringLength(30)]
        public string Season { get; set; }
        

    }
}
