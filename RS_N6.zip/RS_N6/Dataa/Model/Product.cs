﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dataa.Model
{
   public class Product
    {
        public int Id { get; set; }
        [StringLength(50)]
        [Required]
        public string Name { get; set; }
        public Brand Brand { get; set; }
        public Category Category { get; set; }

        public double Price { get; set; }
        public string Size{ get; set; }
        [StringLength(30)]
        public string Color{ get; set; }
        [StringLength(30)]
        public string Material { get; set; }
        public DateTime? ProductionDate { get; set; }
        public  Gender Gender { get; set; }
     
    }
}

