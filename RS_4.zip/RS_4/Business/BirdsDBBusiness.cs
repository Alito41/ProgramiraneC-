﻿using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Business
{
    public class BirdsDBBusiness
    {
            private BirdsDBContext birdsDBContext;
            public List<Bird> GetAllBirds()
            {
                using (birdsDBContext = new BirdsDBContext())
                {
                    return birdsDBContext.Birds.ToList();
                }
            }
            public Bird GetBird(int id)
            {
                using (birdsDBContext = new BirdsDBContext())
                {
                    return birdsDBContext.Birds.Find(id);
                }
            }

            public void AddBird(Bird product)
            {
                using (birdsDBContext = new BirdsDBContext())
                {
                    birdsDBContext.Birds.Add(product);
                    birdsDBContext.SaveChanges();
                }

            }

            public void UpdateBird(Bird product)
            {
                using (birdsDBContext = new BirdsDBContext())
                {

                    var item = birdsDBContext.Birds.Find(product.Id);
                    if (item != null)
                    {
                        birdsDBContext.Entry(item).CurrentValues.SetValues(product);
                        birdsDBContext.SaveChanges();

                    }

                }
            }
            public void DeleteBird(int id)
            {
                var product = birdsDBContext.Birds.Find(id);
                if (product != null)
                {
                    birdsDBContext.Birds.Remove(product);
                    birdsDBContext.SaveChanges();

                }

            }

            public void ShowMenuBird()
            {

                Console.WriteLine();

            }



        }
    }

