﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Model
{
    public class Observer
    {
        public int Id { get; set; }
        

        [Column("Observer Name")][StringLength(45)]
        public string ObserverName { get; set; }
        

        [Column("Observer Email")][Required]
        public string ObserverEmail { get; set; }

        public List<SightingBird> SightingBirds { get; set; }
        public List<Sighting> Sightings { get; set; }

    }
}
