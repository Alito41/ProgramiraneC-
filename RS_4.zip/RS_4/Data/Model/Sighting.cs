﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Model
{
    public class Sighting
    {
        public int Id { get; set; }


        [StringLength(50)][Required]
        public string Location { get; set; }
        [Required]
        public DateTime? ObserverDate { get; set; }

        public List<SightingBird> SightingBirds { get; set; }
        public Observer Observers { get; set; }


        // public int ObserverId { get; set; }

    }
}
