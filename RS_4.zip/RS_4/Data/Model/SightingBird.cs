﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Model
{
    public class SightingBird
    {
        public int Id { get; set; }

        public List<Bird> Bird { get; set; }

        public List<Sighting> Sighting { get; set; }
     //   public int BirdsId { get; set; }
      //  public int SightingsId { get; set; }
    }
}
