﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Model
{
    public class Bird
    {
        public int Id { get; set; }


        [Column("Species Name")]
        [StringLength(100)]
        public string SpeciesName { get; set; }
        
        [Column("Scientific Name")][StringLength(100)]
        public string ScientificName { get; set; }
        
        [Column("Avarage Size")][Required]
        public decimal AverageSize { get; set; }

        [Column("Primary Color")][StringLength(50)][Required]
        public string PrimaryColor { get; set; }
        

        [Column("Habitat")][StringLength(100)][Required] 
        public string Habitat { get; set; }
        
        [Column("Diet")]
        [StringLength(100)][Required]
        public string Diet { get; set; }

        public List<SightingBird> SightingBirds { get; set; }



    }
    
}
