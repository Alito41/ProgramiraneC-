﻿using Business;
using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentation
{
    public class Display
    {
        BirdsDBBusiness birdsDBBusiness = new BirdsDBBusiness();
        private int closeOperationId = 6;


        private void ShowMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 18) + "MENU" + new string(' ', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all entries");
            Console.WriteLine("2. Add new entry");
            Console.WriteLine("3. Update entry");
            Console.WriteLine("4. Fetch entry by ID");
            Console.WriteLine("5. Delete entry by ID");
            Console.WriteLine("6. Exit");

        }

        public Display()
        {
            Input();
        }
        private void Input()
        {
            var operation = -1;
            do
            {

                ShowMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        ListAll();
                        break;
                    case 2:
                        Add();
                        break;
                    case 3:
                        Update();
                        break;
                    case 4:
                        Fetch();
                        break;
                    case 5:
                        Delete();
                        break;
                    default:
                        break;
                }
            } while (operation != closeOperationId); }

        private void Add()
        {
            Bird birdsDB = new Bird();
            Console.WriteLine("Enter Species name: ");
            birdsDB.SpeciesName = Console.ReadLine();
            Console.WriteLine("Enter Scientific name: ");
            birdsDB.ScientificName = Console.ReadLine();
            Console.WriteLine("Enter Average Size: ");
            birdsDB.AverageSize = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter Primary Color: ");
            birdsDB.PrimaryColor = Console.ReadLine();
            Console.WriteLine("Enter Habitat: ");
            birdsDB.Habitat = Console.ReadLine();
            Console.WriteLine("Enter Diet: ");
            birdsDB.Diet = Console.ReadLine();
            birdsDBBusiness.AddBird(birdsDB);
        }

        private void ListAll()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 16) + "PRODUCTS" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            var product = birdsDBBusiness.GetAllBirds();
            foreach (var item in product)
            {

                Console.WriteLine("{0} {1} {2} {3}", item.SpeciesName, item.ScientificName, item.AverageSize,item.PrimaryColor,item.Habitat,item.Diet);
            }
        }

        private void Update()
        {
            int id = int.Parse(Console.ReadLine());
            Bird birdsDB = birdsDBBusiness.GetBird(id);
            int.Parse(Console.ReadLine());
           
            if (birdsDB != null)
            {
               
                Console.WriteLine("Enter Species name: ");
                birdsDB.SpeciesName = Console.ReadLine();
                Console.WriteLine("Enter Scientific name: ");
                birdsDB.ScientificName = Console.ReadLine();
                Console.WriteLine("Enter Average Size: ");
                birdsDB.AverageSize = decimal.Parse(Console.ReadLine());
                Console.WriteLine("Enter Primary Color: ");
                birdsDB.PrimaryColor = Console.ReadLine();
                Console.WriteLine("Enter Habitat: ");
                birdsDB.Habitat = Console.ReadLine();
                Console.WriteLine("Enter Diet: ");
                birdsDB.Diet = Console.ReadLine();
                birdsDBBusiness.UpdateBird(birdsDB);
            }
            else
            {
                Console.WriteLine("BirdsDBContext not found!");
            }
        }
        private void Fetch()
        {
            Console.WriteLine("Enter ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            Bird birdsDB = birdsDBBusiness.GetBird(id);
            if (birdsDB != null)
            {
                Console.WriteLine(new string('-', 40));
                // Console.WriteLine("ID: " + product.Id);
                Console.WriteLine("Species Name: " + birdsDB.SpeciesName);
                Console.WriteLine("Scientific Name: " + birdsDB.ScientificName);
                Console.WriteLine("Avarage Size: " + birdsDB.AverageSize);
                Console.WriteLine("Primary Color: " + birdsDB.PrimaryColor);
                Console.WriteLine("Habitat: " + birdsDB.Habitat);
                Console.WriteLine("Diet: " + birdsDB.Diet);
                Console.WriteLine(new string('-', 40));

            }
        }


        private void Delete()
        {
            Console.WriteLine("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            birdsDBBusiness.DeleteBird(id);
            Console.WriteLine("Done.");
        }
    }

    } 
