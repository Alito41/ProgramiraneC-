﻿using Data.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System;

namespace Data
{
    public class FitnessContext:DbContext
    {
        public DbSet<FitnessProduct> FitnessProducts { get; set; }
        public DbSet<FitnessIngredient> FitnessIngredients { get; set; }
        public DbSet<FitnessProductIngredient> FitnessProductIngredients { get; set; }
        public FitnessContext()
        {
            Database.EnsureCreated();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=FitnessDB;");
        }
    }
}
