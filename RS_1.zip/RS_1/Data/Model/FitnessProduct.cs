﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Model
{
    public class FitnessProduct
    {
        public int Id { get; set; }
        [StringLength(50)]
        [Required]
        public string Name { get; set; }
        [StringLength(50)]
        public string Category { get; set; }
        public float Price { get; set; }
        public int StockQuantity { get; set; }
        public List<FitnessProductIngredient> FitnessProductsIngredient { get; set; }
        public DateTime? ExpireDate { get; set; }
    }
}
