﻿using Busines;
using Data.Model;
using System;

namespace Presentation
{

    public class Display
    {
        FitnessBusines fitnessBusiness = new FitnessBusines();
        private void ShowMenu()
        {
            Console.WriteLine(new string('-',40));
            Console.WriteLine(new string('-',18) + "MENU" + new string(' ',18));
            Console.WriteLine(new string('-',40));
            Console.WriteLine("1. List all entries");
            Console.WriteLine("2. Add new entry");
            Console.WriteLine("3. Update entry");
            Console.WriteLine("4. Fetch entry by ID");
            Console.WriteLine("5. Delete entry by ID");
            Console.WriteLine("6. Exit");
        }

        private void ShowMainMenu()
        {
            var operation = -1;
            do
            {
                ShowMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        GetAllFitnessProduct();
                        break;
                    case 2:
                        AddFitnessProduct();
                        break;
                    case 3:
                        UpdateFitnessProduct();
                        break;
                    case 4:
                        GetFitnessProductID();
                        break;
                    case 5:
                        DeleteFitnessProduct();
                        break;
                    default:
                        break;
                }
            } while (operation != closeOperationId);
        } 
        
        private int closeOperationId = 6;
        public Display()
        {
            ShowMainMenu();
        }

        private void AddFitnessProduct()
        {
            FitnessProduct fitnessProduct = new FitnessProduct();
            Console.WriteLine("Enter name: ");
            fitnessProduct.Name = Console.ReadLine();
            Console.WriteLine("Enter Category: ");
            fitnessProduct.Category = Console.ReadLine();
            Console.WriteLine("Enter Price: ");
            fitnessProduct.Price = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Stock Quantity: ");
            fitnessProduct.StockQuantity = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Date Time: ");
            fitnessProduct.ExpireDate = DateTime.Parse(Console.ReadLine());
            fitnessBusiness.AddFitnessProduct(fitnessProduct);
        }

        private void GetAllFitnessProduct()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 16) + "PRODUCT" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            var products = fitnessBusiness.GetAllFitnessProduct();
            foreach (var item in products)
            {
                Console.WriteLine("{0} {1} {2} {3} {4} {5}",item.Id,item.Name,item.Category,item.Price,item.StockQuantity,item.ExpireDate);
            }
        }

        private void UpdateFitnessProduct()
        {
            Console.WriteLine("Enter ID to update: ");
            int id = int.Parse(Console.ReadLine());
            FitnessProduct Product = fitnessBusiness.GetFitnessProductID(id);
            if (Product != null)
            {
                Console.WriteLine("Enter name: ");
                Product.Name = Console.ReadLine();
                Console.WriteLine("Enter Category: ");
                Product.Category = Console.ReadLine();
                Console.WriteLine("Enter Price: ");
                Product.Price = float.Parse(Console.ReadLine());
                Console.WriteLine("Enter Stock Quantity: ");
                Product.StockQuantity = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Date Time: ");
                Product.ExpireDate = DateTime.Parse(Console.ReadLine());
                fitnessBusiness.UpdateFitnessProduct(Product);
            }
            else
            {
                Console.WriteLine("Product not found!");
            }
        }

        private void GetFitnessProductID()
        {
            Console.WriteLine("Enter ID to get: ");
            int id = int.Parse(Console.ReadLine());
            FitnessProduct Product = fitnessBusiness.GetFitnessProductID(id);
            if (Product != null)
            {
                Console.WriteLine(new string('-',40));
                Console.WriteLine("ID: "+Product.Id);
                Console.WriteLine("Name: "+Product.Name);
                Console.WriteLine("Category: "+Product.Category);
                Console.WriteLine("Price: "+Product.Price);
                Console.WriteLine("Date Time: "+Product.ExpireDate);
            }
        }

        private void DeleteFitnessProduct()
        {
            Console.WriteLine("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            fitnessBusiness.DeleteFitnessProduct(id);
            Console.WriteLine("Done");
        }
    }
}
