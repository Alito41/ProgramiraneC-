﻿using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Busines
{
    public class FitnessBusines
    {
       
            private FitnessContext FitnessContext;
            public List<FitnessProduct> GetAllFitnessProduct()
            {
                using (FitnessContext = new FitnessContext())
                {
                    return FitnessContext.FitnessProducts.ToList();
                }
            }
            public FitnessProduct GetFitnessProductID(int id)
            {
                using (FitnessContext = new FitnessContext())
                {
                    return FitnessContext.FitnessProducts.Find(id);
                }
            }

            public void AddFitnessProduct(FitnessProduct product)
            {
                using (FitnessContext = new FitnessContext())
                {
                    FitnessContext.FitnessProducts.Add(product);
                    FitnessContext.SaveChanges();
                }

            }

            public void UpdateFitnessProduct(FitnessProduct product)
            {
                using (FitnessContext = new FitnessContext())
                {

                    var item = FitnessContext.FitnessProducts.Find(product.Id);
                    if (item != null)
                    {
                        FitnessContext.Entry(item).CurrentValues.SetValues(product);
                        FitnessContext.SaveChanges();

                    }

                }
            }

            public void DeleteFitnessProduct(int id)
            {
            using (FitnessContext = new FitnessContext())
            {
                var product = FitnessContext.FitnessProducts.Find(id);
                if (product != null)
                {
                    FitnessContext.FitnessProducts.Remove(product);
                    FitnessContext.SaveChanges();
                }
            }
            }

            public void ShowMenu()
            {

                Console.WriteLine();

            }
    }
}
