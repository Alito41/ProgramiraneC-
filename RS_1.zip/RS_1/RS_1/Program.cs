﻿using Data;
using System;

namespace RS_1
{
    class Program
    {
        static void Main(string[] args)
        {
            FitnessContext context = new FitnessContext();
        }
    }
}
